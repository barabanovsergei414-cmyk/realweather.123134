package com.realisticfiresmoke;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Client-side config: how much extra ember and smoke the mod adds, and how far from the player. */
public final class FireConfig {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.BooleanValue ENABLED;
    public static final ModConfigSpec.IntValue RADIUS;
    public static final ModConfigSpec.DoubleValue EMBER_DENSITY;
    public static final ModConfigSpec.DoubleValue SMOKE_DENSITY;
    public static final ModConfigSpec.IntValue MAX_SOURCES_PER_SCAN;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        b.push("fireSmoke");
        ENABLED = b.comment("Add extra embers and thick smoke near fire, campfires and lava")
                .define("enabled", true);
        RADIUS = b.comment("How far from the player (blocks) the mod looks for fire sources")
                .defineInRange("radius", 20, 4, 48);
        EMBER_DENSITY = b.comment("Embers per source per second. Lower this on weaker PCs (GTX 1650 class: try 1.0-2.0)")
                .defineInRange("emberDensity", 2.0, 0.0, 10.0);
        SMOKE_DENSITY = b.comment("Smoke puffs per source per second")
                .defineInRange("smokeDensity", 1.5, 0.0, 10.0);
        MAX_SOURCES_PER_SCAN = b.comment("Safety cap: at most this many fire/lava/campfire blocks get extra effects at once")
                .defineInRange("maxSourcesPerScan", 24, 4, 128);
        b.pop();
        SPEC = b.build();
    }

    private FireConfig() {}
}
