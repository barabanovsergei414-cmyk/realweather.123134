package com.realisticfiresmoke;

import com.realisticfiresmoke.client.ClientSetup;
import com.realisticfiresmoke.client.FireAmbienceHandler;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(RealisticFireSmoke.MODID)
public class RealisticFireSmoke {
    public static final String MODID = "realisticfiresmoke";

    public static final DeferredRegister<ParticleType<?>> PARTICLE_TYPES =
            DeferredRegister.create(Registries.PARTICLE_TYPE, MODID);

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> EMBER =
            PARTICLE_TYPES.register("ember", () -> new SimpleParticleType(false));

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> THICK_SMOKE =
            PARTICLE_TYPES.register("thick_smoke", () -> new SimpleParticleType(false));

    public RealisticFireSmoke(IEventBus modBus, ModContainer container) {
        PARTICLE_TYPES.register(modBus);
        container.registerConfig(ModConfig.Type.CLIENT, FireConfig.SPEC);

        if (FMLEnvironment.dist == Dist.CLIENT) {
            modBus.addListener(ClientSetup::registerParticleProviders);
            NeoForge.EVENT_BUS.register(new FireAmbienceHandler());
        }
    }
}
