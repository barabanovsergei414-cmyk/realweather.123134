package com.realisticfiresmoke.client;

import com.realisticfiresmoke.RealisticFireSmoke;
import com.realisticfiresmoke.client.particle.EmberParticle;
import com.realisticfiresmoke.client.particle.ThickSmokeParticle;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

public final class ClientSetup {
    private ClientSetup() {}

    public static void registerParticleProviders(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(RealisticFireSmoke.EMBER.get(), EmberParticle.Provider::new);
        event.registerSpriteSet(RealisticFireSmoke.THICK_SMOKE.get(), ThickSmokeParticle.Provider::new);
    }
}
