package com.realisticfiresmoke.client;

import com.realisticfiresmoke.FireConfig;
import com.realisticfiresmoke.RealisticFireSmoke;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Every few ticks, scans a small area around the player for fire, lit campfires and lava,
 * and spawns extra ember and thick-smoke particles there, on top of vanilla's own effects.
 * Client-only, capped for performance (see FireConfig.MAX_SOURCES_PER_SCAN).
 */
public class FireAmbienceHandler {
    private static final int SCAN_INTERVAL_TICKS = 5;
    private int tickCounter = 0;
    private final List<BlockPos> sourceCache = new ArrayList<>();
    private int rescanCooldown = 0;

    @SubscribeEvent
    public void onClientTick(ClientTickEvent.Post event) {
        if (!FireConfig.ENABLED.get()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || mc.player == null) return;

        tickCounter++;
        if (tickCounter % SCAN_INTERVAL_TICKS != 0) return;

        if (rescanCooldown <= 0) {
            rescan(level, mc.player.blockPosition());
            rescanCooldown = 20;   // re-scan for new/removed sources about once a second
        } else {
            rescanCooldown -= SCAN_INTERVAL_TICKS;
        }

        if (sourceCache.isEmpty()) return;
        double emberChance = FireConfig.EMBER_DENSITY.get() * SCAN_INTERVAL_TICKS / 20.0;
        double smokeChance = FireConfig.SMOKE_DENSITY.get() * SCAN_INTERVAL_TICKS / 20.0;

        for (BlockPos pos : sourceCache) {
            double cx = pos.getX() + 0.5;
            double cz = pos.getZ() + 0.5;
            double cy = pos.getY() + 1.0;
            var rnd = level.random;

            if (rnd.nextDouble() < emberChance) {
                double ex = cx + (rnd.nextDouble() - 0.5) * 0.6;
                double ez = cz + (rnd.nextDouble() - 0.5) * 0.6;
                level.addParticle(RealisticFireSmoke.EMBER.get(), ex, cy, ez, 0.0, 0.0, 0.0);
            }
            if (rnd.nextDouble() < smokeChance) {
                double sx = cx + (rnd.nextDouble() - 0.5) * 0.4;
                double sz = cz + (rnd.nextDouble() - 0.5) * 0.4;
                level.addParticle(RealisticFireSmoke.THICK_SMOKE.get(), sx, cy + 0.2, sz, 0.0, 0.0, 0.0);
            }
        }
    }

    private void rescan(ClientLevel level, BlockPos center) {
        sourceCache.clear();
        int radius = FireConfig.RADIUS.get();
        int cap = FireConfig.MAX_SOURCES_PER_SCAN.get();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();

        outer:
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -8; dy <= 8; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    int x = center.getX() + dx;
                    int y = center.getY() + dy;
                    int z = center.getZ() + dz;
                    m.set(x, y, z);
                    if (!level.hasChunkAt(m)) continue;
                    BlockState state = level.getBlockState(m);
                    boolean isSource = state.is(Blocks.FIRE) || state.is(Blocks.SOUL_FIRE)
                            || (state.getBlock() instanceof CampfireBlock && state.getValue(CampfireBlock.LIT))
                            || state.getFluidState().getType() == Fluids.LAVA;
                    if (isSource) {
                        sourceCache.add(m.immutable());
                        if (sourceCache.size() >= cap) break outer;
                    }
                }
            }
        }
    }
}
