package com.realisticfiresmoke.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/**
 * A glowing ember: rises with heat, flickers between orange and red, drifts slightly
 * sideways (turbulence, not wind-synced), shrinks and darkens as it cools, then dies out.
 */
public class EmberParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final float baseRCol;
    private final float wobblePhase;

    protected EmberParticle(ClientLevel level, double x, double y, double z,
                             double vx, double vy, double vz, SpriteSet sprites) {
        super(level, x, y, z, vx, vy, vz);
        this.sprites = sprites;
        this.lifetime = 20 + this.random.nextInt(24);
        this.gravity = -0.015f;   // heat buoyancy: rises slowly instead of falling
        this.friction = 0.96f;
        this.quadSize = 0.07f + this.random.nextFloat() * 0.05f;
        this.xd = vx + (this.random.nextDouble() - 0.5) * 0.02;
        this.yd = vy + 0.04 + this.random.nextDouble() * 0.05;
        this.zd = vz + (this.random.nextDouble() - 0.5) * 0.02;
        this.baseRCol = 1.0f;
        this.wobblePhase = this.random.nextFloat() * 6.2831855f;
        this.hasPhysics = false;
        setSpriteFromAge(sprites);
        updateColor();
    }

    private void updateColor() {
        float lifeFrac = (float) this.age / (float) this.lifetime;
        // bright yellow-white core when young, cooling through orange to dark red/ash as it ages
        float r = baseRCol;
        float g = Math.max(0.15f, 0.75f - lifeFrac * 0.65f);
        float bl = Math.max(0.0f, 0.35f - lifeFrac * 0.4f);
        float flicker = 0.9f + 0.1f * net.minecraft.util.Mth.sin(this.age * 1.3f + wobblePhase);
        setColor(r * flicker, g * flicker, bl);
        this.alpha = 1.0f - lifeFrac * lifeFrac;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.removed) {
            this.xd += (this.random.nextDouble() - 0.5) * 0.004;
            this.zd += (this.random.nextDouble() - 0.5) * 0.004;
            this.quadSize = Math.max(0.01f, this.quadSize - 0.002f);
            updateColor();
            setSpriteFromAge(sprites);
        }
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                        double x, double y, double z, double vx, double vy, double vz) {
            return new EmberParticle(level, x, y, z, vx, vy, vz, sprites);
        }
    }
}
