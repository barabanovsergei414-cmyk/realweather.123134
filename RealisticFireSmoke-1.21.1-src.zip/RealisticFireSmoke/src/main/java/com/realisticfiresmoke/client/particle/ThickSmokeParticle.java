package com.realisticfiresmoke.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/**
 * Thicker, slower, more turbulent smoke than vanilla: grows as it rises, curls sideways,
 * darkest near the source and lightening as it disperses, with a long fade-out.
 */
public class ThickSmokeParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final double curlFreq;
    private final double curlPhase;
    private final float growTo;

    protected ThickSmokeParticle(ClientLevel level, double x, double y, double z,
                                  double vx, double vy, double vz, SpriteSet sprites) {
        super(level, x, y, z, vx, vy, vz);
        this.sprites = sprites;
        this.lifetime = 60 + this.random.nextInt(60);
        this.gravity = 0.0f;
        this.friction = 0.98f;
        this.quadSize = 0.6f + this.random.nextFloat() * 0.3f;
        this.growTo = this.quadSize * (2.2f + this.random.nextFloat() * 1.3f);
        this.xd = vx;
        this.yd = vy + 0.03 + this.random.nextDouble() * 0.03;
        this.zd = vz;
        this.curlFreq = 0.06 + this.random.nextDouble() * 0.05;
        this.curlPhase = this.random.nextDouble() * Math.PI * 2.0;
        this.hasPhysics = true;
        float grey = 0.08f + this.random.nextFloat() * 0.06f;
        setColor(grey, grey, grey);
        this.alpha = 0.75f;
        setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.removed) return;

        float lifeFrac = (float) this.age / (float) this.lifetime;
        // curl sideways like real smoke caught in slow air currents
        double curl = Math.sin(this.age * curlFreq + curlPhase);
        this.xd += curl * 0.003;
        this.zd += Math.cos(this.age * curlFreq + curlPhase) * 0.003;
        this.yd *= 0.995;

        float growFrac = Math.min(1.0f, lifeFrac * 2.5f);
        this.quadSize = net.minecraft.util.Mth.lerp(growFrac, this.quadSize, this.growTo);

        // lighten and thin out as it disperses into the air
        float grey = net.minecraft.util.Mth.lerp(lifeFrac, 0.10f, 0.55f);
        setColor(grey, grey, grey);
        this.alpha = 0.75f * (1.0f - lifeFrac * lifeFrac);
        setSpriteFromAge(sprites);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                        double x, double y, double z, double vx, double vy, double vz) {
            return new ThickSmokeParticle(level, x, y, z, vx, vy, vz, sprites);
        }
    }
}
